# Fiji Patient - Draft Fiji Core Implementation Guide v0.2.0

## Resource Profile: Fiji Patient 

 
Patient profile for Fiji jurisdiction. 
Integrates: 
* FijiHumanName
* Patient-level clan affiliation
* Guidance for usual vs official name use
 

**Usages:**

* Refer to this Profile: [Fiji Allergy/Intolerance](StructureDefinition-fiji-allergy-intolerance.md), [Fiji Condition](StructureDefinition-fiji-condition.md), [Fiji Diagnostic Observation](StructureDefinition-fiji-diagnostic-observation.md), [Fiji Healthcare Encounter](StructureDefinition-fiji-encounter.md)... Show 11 more, [Fiji Immunization](StructureDefinition-fiji-immunization.md), [Fiji Pathology Observation](StructureDefinition-fiji-pathology-observation.md), [Blood Pressure Observation](StructureDefinition-fiji-vital-blood-pressure.md), [BMI Vitals - Fiji](StructureDefinition-fiji-vital-bmi.md), [Body Temperature Vitals - Fiji](StructureDefinition-fiji-vital-body-temperature.md), [Head circumference Vitals - Fiji](StructureDefinition-fiji-vital-head-circumference.md), [Heart Rate Vitals - Fiji](StructureDefinition-fiji-vital-heart-rate.md), [Height Vitals - Fiji](StructureDefinition-fiji-vital-height.md), [Oxygen Saturation Vitals - Fiji](StructureDefinition-fiji-vital-oxygen-saturation.md), [Respiratory Rate Vitals - Fiji](StructureDefinition-fiji-vital-respiratory-rate.md) and [Weight Vitals - Fiji](StructureDefinition-fiji-vital-weight.md)
* Examples for this Profile: [Patient/FijiPatientExample](Patient-FijiPatientExample.md), [Patient/FijiPatientExample1](Patient-FijiPatientExample1.md), [Patient/FijiPatientExample2](Patient-FijiPatientExample2.md) and [Patient/FijiPatientFijiIndo](Patient-FijiPatientFijiIndo.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/health.gov.fhir.fj.core|current/StructureDefinition/StructureDefinition-fiji-patient.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-fiji-patient.csv), [Excel](../StructureDefinition-fiji-patient.xlsx), [Schematron](../StructureDefinition-fiji-patient.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fiji-patient",
  "url" : "https://core.fhir.health.gov.fj/StructureDefinition/fiji-patient",
  "version" : "0.2.0",
  "name" : "FijiPatient",
  "title" : "Fiji Patient",
  "status" : "active",
  "date" : "2026-09-11T02:30:38+00:00",
  "publisher" : "MHMS Fiji",
  "contact" : [{
    "name" : "MHMS Fiji",
    "telecom" : [{
      "system" : "url",
      "value" : "https://fhir.health.gov.fj"
    }]
  },
  {
    "name" : "Support",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.fhir.health.gov.fj"
    }]
  }],
  "description" : "Patient profile for Fiji jurisdiction.\n\nIntegrates:\n- FijiHumanName\n- Patient-level clan affiliation\n- Guidance for usual vs official name use",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FJ",
      "display" : "Fiji"
    }]
  }],
  "copyright" : "Distributed under the Creative Commons CC0-1.0 License (https://creativecommons.org/publicdomain/zero/1.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "loinc",
    "uri" : "http://loinc.org",
    "name" : "LOINC code for the element"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Patient",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Patient",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Patient",
      "path" : "Patient"
    },
    {
      "id" : "Patient.extension",
      "path" : "Patient.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Patient.extension:healthZone",
      "path" : "Patient.extension",
      "sliceName" : "healthZone",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://core.fhir.health.gov.fj/StructureDefinition/fiji-admin-zone"]
      }]
    },
    {
      "id" : "Patient.extension:nationality",
      "path" : "Patient.extension",
      "sliceName" : "nationality",
      "short" : "The patient's nationality",
      "definition" : "The nationality represented using ISO 3166 2 letter country codes.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/patient-nationality"]
      }]
    },
    {
      "id" : "Patient.extension:nationality.extension:code",
      "path" : "Patient.extension.extension",
      "sliceName" : "code"
    },
    {
      "id" : "Patient.extension:nationality.extension:code.value[x]",
      "path" : "Patient.extension.extension.value[x]",
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/iso3166-1-2"
      }
    },
    {
      "id" : "Patient.extension:religion",
      "path" : "Patient.extension",
      "sliceName" : "religion",
      "short" : "The patient's religious affiliation",
      "definition" : "The patient's professed religious affilition with an extensible valueset based on [ReligiousAffiliation valueset](http://terminology.hl7.org/ValueSet/v3-ReligiousAffiliation).",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/patient-religion"]
      }]
    },
    {
      "id" : "Patient.extension:occupation",
      "path" : "Patient.extension",
      "sliceName" : "occupation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://core.fhir.health.gov.fj/StructureDefinition/fiji-patient-occupation"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.extension:ethnicity",
      "path" : "Patient.extension",
      "sliceName" : "ethnicity",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://core.fhir.health.gov.fj/StructureDefinition/fiji-patient-ethnicity"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.identifier",
      "path" : "Patient.identifier",
      "short" : "Identifers (e.g., national ID, medical record number)",
      "definition" : "Strongly recommended to includes national identification numbers as well as other medical record numbers.",
      "min" : 1
    },
    {
      "id" : "Patient.name",
      "path" : "Patient.name",
      "short" : "At least one name required; usual preferred for display",
      "min" : 1,
      "type" : [{
        "code" : "HumanName",
        "profile" : ["https://core.fhir.health.gov.fj/StructureDefinition/fiji-humanname"]
      }]
    },
    {
      "id" : "Patient.gender",
      "path" : "Patient.gender",
      "mustSupport" : true
    },
    {
      "id" : "Patient.birthDate",
      "path" : "Patient.birthDate",
      "short" : "Date of birth, may be flagged as estimated via extension",
      "mustSupport" : true
    },
    {
      "id" : "Patient.birthDate.extension",
      "path" : "Patient.birthDate.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Patient.birthDate.extension:birthDateEstimated",
      "path" : "Patient.birthDate.extension",
      "sliceName" : "birthDateEstimated",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://core.fhir.health.gov.fj/StructureDefinition/birthdate-estimated-indicator"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Patient.address",
      "path" : "Patient.address",
      "type" : [{
        "code" : "Address",
        "profile" : ["https://core.fhir.health.gov.fj/StructureDefinition/fiji-address"]
      }]
    },
    {
      "id" : "Patient.communication",
      "path" : "Patient.communication",
      "short" : "Languages patient can use"
    },
    {
      "id" : "Patient.generalPractitioner",
      "path" : "Patient.generalPractitioner",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "short" : "Care providers for this patient; prefer Fiji-specific profiles"
    },
    {
      "id" : "Patient.generalPractitioner:practitioner",
      "path" : "Patient.generalPractitioner",
      "sliceName" : "practitioner",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://core.fhir.health.gov.fj/StructureDefinition/fiji-practitioner",
        "http://hl7.org/fhir/StructureDefinition/Practitioner"]
      }]
    },
    {
      "id" : "Patient.generalPractitioner:role",
      "path" : "Patient.generalPractitioner",
      "sliceName" : "role",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://core.fhir.health.gov.fj/StructureDefinition/fiji-practitioner-role",
        "http://hl7.org/fhir/StructureDefinition/PractitionerRole"]
      }]
    },
    {
      "id" : "Patient.managingOrganization",
      "path" : "Patient.managingOrganization",
      "short" : "Organization responsible for the patient; prefer Fiji specific profiles",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["https://core.fhir.health.gov.fj/StructureDefinition/fiji-organization",
        "http://hl7.org/fhir/StructureDefinition/Organization"]
      }]
    }]
  }
}

```
