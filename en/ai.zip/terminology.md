# Terminology - Draft Fiji Core Implementation Guide v0.2.2

## Terminology

# Terminology

This page describes code systems and valuesets that are used in this Implementation Guide.

