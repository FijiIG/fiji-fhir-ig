# Example Total Cholesterol - Draft Fiji Core Implementation Guide v0.2.2

## Example Observation: Example Total Cholesterol

Profile: [Fiji Pathology Observation](StructureDefinition-fiji-pathology-observation.md)

**status**: Final

**category**: Laboratory

**code**: Cholesterol [Mass/volume] in Serum or Plasma

**subject**: [Patient/FijiExamplePatient](Patient/FijiExamplePatient)

**effective**: 2026-09-23 09:00:00+1200

**value**: 4.8 mmol/L (Details: UCUM codemmol/L = 'mmol/L')

**specimen**: [Specimen: status = final; type = Serum specimen; receivedTime = 2026-09-23 09:15:00+1200](Specimen-ExampleLipidSpecimen.md)



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "ExampleTotalCholesterol",
  "meta" : {
    "profile" : ["https://core.fhir.health.gov.fj/StructureDefinition/fiji-pathology-observation"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "laboratory"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "2093-3",
      "display" : "Cholesterol [Mass/volume] in Serum or Plasma"
    }]
  },
  "subject" : {
    "reference" : "Patient/FijiExamplePatient"
  },
  "effectiveDateTime" : "2026-09-23T09:00:00+12:00",
  "valueQuantity" : {
    "value" : 4.8,
    "system" : "http://unitsofmeasure.org",
    "code" : "mmol/L"
  },
  "specimen" : {
    "reference" : "Specimen/ExampleLipidSpecimen"
  }
}

```
