# health.gov.fhir.fj.core#0.2.1: Draft Fiji Core Implementation Guide(en)

## Pages

* [Fiji Core Implementation Guide](index.md)
* [Data Type Profiles](datatypes.md)
* [Contributing to the Fiji Core IG](gettingstarted.md)
* [Artifacts Summary](artifacts.md)
* [Resource Profiles](resources.md)
* [Extensions](extensions.md)
* [Terminology](terminology.md)

## Resources

### CodeSystems

* [Health administrative division codes in Fiji](CodeSystem-fiji-division-cs.md)
* [Health administrative medical area codes in Fiji](CodeSystem-fiji-medical-area-cs.md)
* [Health administrative nursing zone codes in Fiji](CodeSystem-fiji-nursing-zone-cs.md)
* [Observation interpretation local codes in Fiji](CodeSystem-fiji-obs-interpretation-cs.md)
* [Health administrative sub-division codes in Fiji](CodeSystem-fiji-sub-division-cs.md)

### ValueSets

* [Allergy Causative Agent Value Set for Fiji Patient](ValueSet-fiji-allergy-agent-vs.md)
* [Fiji Body Site (Anatomical Structure) Value Set](ValueSet-fiji-body-site-vs.md)
* [Condition/Diagnosis code valueset](ValueSet-fiji-condition-code-vs.md)
* [Valueset of Fiji Health Administration Divisions](ValueSet-fiji-division-vs.md)
* [Condition Evidence Value Set for Fiji Core IG](ValueSet-fiji-evidence-vs.md)
* [Valueset of Fiji Health Administration medical areas](ValueSet-fiji-medical-area-vs.md)
* [Fiji Medication and Vaccine Route Value Set](ValueSet-fiji-medication-route-vs.md)
* [Valueset of Fiji Health Administration nursing zones](ValueSet-fiji-nursing-zone-vs.md)
* [Fiji Observation Interpretation Value Set](ValueSet-fiji-obs-interpretation-vs.md)
* [Fiji Radiology/Diagnostic Findings Value Set](ValueSet-fiji-radiology-findings-vs.md)
* [Valueset of Fiji Health Administration Sub-divisions](ValueSet-fiji-sub-division-vs.md)
* [Fiji Vital Sign Body Weight ValueSet](ValueSet-fiji-vital-body-weight-vs.md)
* [Fiji Vital Sign Measurement Method ValueSet](ValueSet-fiji-vital-method-vs.md)
* [Heart Rate LOINC Codes](ValueSet-heart-rate-loinc.md)
* [Immunization ValueSet](ValueSet-imm-vs.md)
* [Immunization Status Reason valueset for reason a vaccine was not administered](ValueSet-immunization-status-reason.md)
* [Observation ValueSet](ValueSet-obs-vs.md)

### Complex-type Profiles

* [Fiji Address](StructureDefinition-fiji-address.md)
* [Fiji HumanName](StructureDefinition-fiji-humanname.md)

### Resource Profiles

* [Fiji Allergy/Intolerance](StructureDefinition-fiji-allergy-intolerance.md)
* [Fiji Condition](StructureDefinition-fiji-condition.md)
* [Fiji Healthcare Device](StructureDefinition-fiji-device.md)
* [Fiji Diagnostic Observation](StructureDefinition-fiji-diagnostic-observation.md)
* [Fiji Healthcare Encounter](StructureDefinition-fiji-encounter.md)
* [Fiji Immunization](StructureDefinition-fiji-immunization.md)
* [Fiji Laboratory Diagnostic Report](StructureDefinition-fiji-laboratory-diagnostic-report.md)
* [Fiji Healthcare Location](StructureDefinition-fiji-location.md)
* [Fiji Healthcare Service or Organization](StructureDefinition-fiji-organization.md)
* [Fiji Pathology Observation](StructureDefinition-fiji-pathology-observation.md)
* [Fiji Patient](StructureDefinition-fiji-patient.md)
* [Fiji Practitioner Role](StructureDefinition-fiji-practitioner-role.md)
* [Fiji Practitioner](StructureDefinition-fiji-practitioner.md)
* [Fiji Specimen](StructureDefinition-fiji-specimen.md)
* [Blood Pressure Observation](StructureDefinition-fiji-vital-blood-pressure.md)
* [BMI Vitals - Fiji](StructureDefinition-fiji-vital-bmi.md)
* [Body Temperature Vitals - Fiji](StructureDefinition-fiji-vital-body-temperature.md)
* [Head circumference Vitals - Fiji](StructureDefinition-fiji-vital-head-circumference.md)
* [Heart Rate Vitals - Fiji](StructureDefinition-fiji-vital-heart-rate.md)
* [Height Vitals - Fiji](StructureDefinition-fiji-vital-height.md)
* [Oxygen Saturation Vitals - Fiji](StructureDefinition-fiji-vital-oxygen-saturation.md)
* [Respiratory Rate Vitals - Fiji](StructureDefinition-fiji-vital-respiratory-rate.md)
* [Weight Vitals - Fiji](StructureDefinition-fiji-vital-weight.md)

### Extensions

* [Birth Date Estimated Indicator](StructureDefinition-birthdate-estimated-indicator.md)
* [Island](StructureDefinition-fiji-address-island.md)
* [Fiji KoroDina or Village](StructureDefinition-fiji-address-village.md)
* [Fiji Health Administration Zone](StructureDefinition-fiji-admin-zone.md)
* [Fiji Clan Affiliation](StructureDefinition-fiji-clan-affiliation.md)
* [Fiji Patient Ethnicity](StructureDefinition-fiji-patient-ethnicity.md)
* [Fiji Patient Occupation](StructureDefinition-fiji-patient-occupation.md)

### ImplementationGuides

* [Draft Fiji Core Implementation Guide](ImplementationGuide-health-gov-fhir-fj-core.md)

### NamingSystems

* [FijiOrganizationIdentifier](NamingSystem-FijiOrganizationIdentifier.md)
* [FijiPatientIdentifier](NamingSystem-FijiPatientIdentifier.md)
* [FijiPractitionerRegistration](NamingSystem-FijiPractitionerRegistration.md)

### Examples

* [FijiAllergyIntoleranceExample (AllergyIntolerance)](AllergyIntolerance-FijiAllergyIntoleranceExample.md)
* [condition-example-diabetes2 (Condition)](Condition-condition-example-diabetes2.md)
* [ExampleLipidPanelReport (DiagnosticReport)](DiagnosticReport-ExampleLipidPanelReport.md)
* [FijiEncounterExample (Encounter)](Encounter-FijiEncounterExample.md)
* [FijiImmunizationReactionExample (Immunization)](Immunization-FijiImmunizationReactionExample.md)
* [FijiTdapImmunizationExample (Immunization)](Immunization-FijiTdapImmunizationExample.md)
* [Example-BMI (Observation)](Observation-Example-BMI.md)
* [Example-BodyHeight (Observation)](Observation-Example-BodyHeight.md)
* [Example-BodyWeight (Observation)](Observation-Example-BodyWeight.md)
* [ExampleArterialPO2 (Observation)](Observation-ExampleArterialPO2.md)
* [ExampleBloodPressure (Observation)](Observation-ExampleBloodPressure.md)
* [ExampleHDLCholesterol (Observation)](Observation-ExampleHDLCholesterol.md)
* [ExampleLDLCholesterol (Observation)](Observation-ExampleLDLCholesterol.md)
* [ExampleLipidPanel (Observation)](Observation-ExampleLipidPanel.md)
* [ExampleTotalCholesterol (Observation)](Observation-ExampleTotalCholesterol.md)
* [ExampleTriglycerides (Observation)](Observation-ExampleTriglycerides.md)
* [FijiBodyTemperatureExample (Observation)](Observation-FijiBodyTemperatureExample.md)
* [FijiHeadCircumferenceExample (Observation)](Observation-FijiHeadCircumferenceExample.md)
* [FijiTdapReactionObservation (Observation)](Observation-FijiTdapReactionObservation.md)
* [HeartRateExample (Observation)](Observation-HeartRateExample.md)
* [OxygenSaturationExample (Observation)](Observation-OxygenSaturationExample.md)
* [RespiratoryRateExample (Observation)](Observation-RespiratoryRateExample.md)
* [Suva Divisional Hospital (Organization)](Organization-FijiOrganizationExample.md)
* [FijiPatientExample (Patient)](Patient-FijiPatientExample.md)
* [FijiPatientExample1 (Patient)](Patient-FijiPatientExample1.md)
* [FijiPatientExample2 (Patient)](Patient-FijiPatientExample2.md)
* [FijiPatientFijiIndo (Patient)](Patient-FijiPatientFijiIndo.md)
* [FijiPractitionerRoleExample (PractitionerRole)](PractitionerRole-FijiPractitionerRoleExample.md)
* [ExampleLipidSpecimen (Specimen)](Specimen-ExampleLipidSpecimen.md)
