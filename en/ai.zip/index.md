# Fiji Core Implementation Guide - Draft Fiji Core Implementation Guide v0.9.0

## Fiji Core Implementation Guide

### Overview

> **Project Status: In Development** This Implementation Guide is under active development and is not yet available for public or production use. Content, data models, and implementation details are subject to change.

The Fiji Core FHIR Implementation Guide defines the nationally agreed core clinical and administrative data standards for interoperable health information exchange in Fiji. The FHIR Implementation Guide (IG) defines a common set of reusable FHIR artifacts, including: profiles, extensions, concepts, identifiers and terminology to support interoperable health information exchange in Fiji.

The high level goals of this IG are:

* Interoperability specification for health data exchange in Fiji
* Compliance/compatibility guidance for aquisition or development of future health systems/software
* Interface/data structure definition basis for future Health Information Exchange based on OpenHIE
* Future support for Internation Patient Summary (FHIR IPS)

The Fiji Core IG is intended to be maintained as a living artifact and is expected to evolve based on feedback and usage experience from the implementation community. Artifacts are included where there is a clear Fiji-specific requirement, where reuse across implementations is expected, and where the artifact is appropriate for inclusion in a national guide. Where suitable definitions already exist in the core FHIR specification, international implementation guides, or other recognised registries, reuse is preferred over defining new Fiji-specific artifacts.

### Audience

This guide is intended for:

* Health ministries
* Software developers & Implementers
* Clinical informatics specialists
* Clinical/Technical Advisors and Working Groups
* Vendors

### Design & Decision Documents

* [Document Index](https://github.com/FijiIG/fiji-fhir-ig/blob/main/docs/index.md)

### Getting Started, Contributions and Feedback

New users should begin with:

* [Getting Started](gettingstarted.md)

Then review the following key artifacts:

| | |
| :--- | :--- |
| [Resource Profiles](resources.md) | Fiji-specific constrained FHIR resources |
| [Data Type Profiles](datatypes.md) | Fiji-specific constrained or extended FHIR datatypes |
| [Extensions](extensions.md) | Fiji-specific extension data elements |
| [Terminology](terminology.md) | Terminology bindings |
| Downloads | Package and definitions |

### Primary Contributors

The Draft Fiji Core FHIR IG is being developed in collaboration with MHMS Fiji, under the supervision of Digital Health, Technical Advisory Group (TAG), with support from CSIRO Strengthening Standards Capability Project, and Australian Government.

Primary guidance, IG design & development has been provided by [Daniel Foulkes](https://www.linkedin.com/in/daniel-foulkes).

### IP Statement

This Implementation Guide is released under the Creative Commons CC0 1.0 Universal Public Domain Dedication.

This publication includes IP covered under the following statements.

* Distributed under the Creative Commons CC0-1.0 License ([https://creativecommons.org/publicdomain/zero/1.0/)](https://creativecommons.org/publicdomain/zero/1.0/))

* [Health administrative zones in Fiji](CodeSystem-fiji-admin-zones.md): [Central Division - capital regions and surrounding provinces](Organization-FijiDivisionExampleCentral.md), [FijiAdminZonesVS](ValueSet-fiji-admin-zones.md)... Show 6 more, [FijiAdministrativeZone](StructureDefinition-fiji-administrative-zone.md), [Medical Area 1 - somewhere in Savusavu](Organization-FijiMedicalAreaExample.md), [Northern Division - Vanua Levu and Taveuni](Organization-FijiDivisionExample.md), [Nursing Zone 1 - in Medical Area 1 somewhere in Savusavu](Organization-FijiNursingZoneExample.md), [Savusavu sub-division](Organization-FijiSubdivisionExample.md) and [Serua/Namosi sub-division](Organization-FijiSubdivisionExampleNamosi.md)
* [Fiji Korodina CodeSystem](CodeSystem-fiji-korodina.md): [FijiITaukeiAffiliation](StructureDefinition-fiji-iTaukei-affiliation.md), [FijiKorodinaVS](ValueSet-fiji-korodina.md) and [Patient/FijiPatientExample](Patient-FijiPatientExample.md)
* [Fiji Mataqali CodeSystem](CodeSystem-fiji-mataqali.md): [FijiITaukeiAffiliation](StructureDefinition-fiji-iTaukei-affiliation.md), [FijiMataqaliVS](ValueSet-fiji-mataqali.md) and [Patient/FijiPatientExample](Patient-FijiPatientExample.md)
* [Fiji MSupply Medication CodeSystem](CodeSystem-fiji-msupply.md): [FijiMedVS](ValueSet-fiji-med-vs.md), [FijiMedicationDispense](StructureDefinition-fiji-medication-dispense.md) and [FijiMedicationRequest](StructureDefinition-fiji-medication-request.md)
* [Observation interpretation local codes in Fiji](CodeSystem-fiji-obs-interpretation-cs.md): [FijiBMI](StructureDefinition-fiji-vital-bmi.md), [FijiHeadCircumference](StructureDefinition-fiji-vital-head-circumference.md)... Show 8 more, [FijiHeight](StructureDefinition-fiji-vital-height.md), [FijiObsInterpretationVS](ValueSet-fiji-obs-interpretation-vs.md), [FijiOxygenSaturation](StructureDefinition-fiji-vital-oxygen-saturation.md), [FijiRespiratoryRate](StructureDefinition-fiji-vital-respiratory-rate.md), [FijiVitalBloodPressure](StructureDefinition-fiji-vital-blood-pressure.md), [FijiVitalBodyTemperature](StructureDefinition-fiji-vital-body-temperature.md), [FijiVitalHeartRate](StructureDefinition-fiji-vital-heart-rate.md) and [FijiWeight](StructureDefinition-fiji-vital-weight.md)
* [Fiji Tikina CodeSystem](CodeSystem-fiji-tikina.md): [FijiITaukeiAffiliation](StructureDefinition-fiji-iTaukei-affiliation.md), [FijiTikinaVS](ValueSet-fiji-tikina.md), [FijiYasanaVS](ValueSet-fiji-yasana.md) and [Patient/FijiPatientExample](Patient-FijiPatientExample.md)
* [Fiji Tokatoka CodeSystem](CodeSystem-fiji-tokatoka.md): [FijiITaukeiAffiliation](StructureDefinition-fiji-iTaukei-affiliation.md), [FijiTokatokaVS](ValueSet-fiji-tokatoka.md) and [Patient/FijiPatientExample](Patient-FijiPatientExample.md)
* [Fiji Yasana CodeSystem](CodeSystem-fiji-yasana.md): [Patient/FijiPatientExample](Patient-FijiPatientExample.md)
* [Fiji Yavusa CodeSystem](CodeSystem-fiji-yavusa.md): [FijiITaukeiAffiliation](StructureDefinition-fiji-iTaukei-affiliation.md), [FijiYavusaVS](ValueSet-fiji-yavusa.md) and [Patient/FijiPatientExample](Patient-FijiPatientExample.md)


* These codes are excerpted from Digital Imaging and Communications in Medicine (DICOM) Standard, Part 16: Content Mapping Resource, Copyright © 2011 by the National Electrical Manufacturers Association.

* [DICOM Controlled Terminology Definitions](http://hl7.org/fhir/R4/codesystem-dicom-dcim.html): [DiagnosticReport/dr-ct-head-001](DiagnosticReport-dr-ct-head-001.md), [FijiDCMModalityVS](ValueSet-fiji-dcm-modality-vs.md) and [FijiImagingDiagnosticReport](StructureDefinition-fiji-imaging-diagnostic-report.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* LOINC: [DiagnosticReport/ExampleLipidPanelReport](DiagnosticReport-ExampleLipidPanelReport.md), [FijiCondition](StructureDefinition-fiji-condition.md)... Show 21 more, [FijiEvidenceVS](ValueSet-fiji-evidence-vs.md), [FijiLaboratoryDiagnosticReport](StructureDefinition-fiji-laboratory-diagnostic-report.md), [FijiPathologyObservation](StructureDefinition-fiji-pathology-observation.md), [FijiVitalBodyWeightVS](ValueSet-fiji-vital-body-weight-vs.md), [HeartRateVS](ValueSet-heart-rate-loinc.md), [ObsVS](ValueSet-obs-vs.md), [Observation/Example-BMI](Observation-Example-BMI.md), [Observation/Example-BodyHeight](Observation-Example-BodyHeight.md), [Observation/Example-BodyWeight](Observation-Example-BodyWeight.md), [Observation/ExampleArterialPO2](Observation-ExampleArterialPO2.md), [Observation/ExampleBloodPressure](Observation-ExampleBloodPressure.md), [Observation/ExampleHDLCholesterol](Observation-ExampleHDLCholesterol.md), [Observation/ExampleLDLCholesterol](Observation-ExampleLDLCholesterol.md), [Observation/ExampleLipidPanel](Observation-ExampleLipidPanel.md), [Observation/ExampleTotalCholesterol](Observation-ExampleTotalCholesterol.md), [Observation/ExampleTriglycerides](Observation-ExampleTriglycerides.md), [Observation/FijiBodyTemperatureExample](Observation-FijiBodyTemperatureExample.md), [Observation/FijiHeadCircumferenceExample](Observation-FijiHeadCircumferenceExample.md), [Observation/HeartRateExample](Observation-HeartRateExample.md), [Observation/OxygenSaturationExample](Observation-OxygenSaturationExample.md) and [Observation/RespiratoryRateExample](Observation-RespiratoryRateExample.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [AllergyIntolerance/FijiAllergyIntoleranceExample](AllergyIntolerance-FijiAllergyIntoleranceExample.md), [Condition/condition-example-diabetes2](Condition-condition-example-diabetes2.md)... Show 48 more, [DiagnosticReport/dr-ct-head-001](DiagnosticReport-dr-ct-head-001.md), [Encounter/FijiEncounterExample](Encounter-FijiEncounterExample.md), [FijiAllergyAgentVS](ValueSet-fiji-allergy-agent-vs.md), [FijiAllergyIntolerance](StructureDefinition-fiji-allergy-intolerance.md), [FijiBodyPositionVS](ValueSet-fiji-body-position-vs.md), [FijiBodySiteVS](ValueSet-fiji-body-site-vs.md), [FijiCondition](StructureDefinition-fiji-condition.md), [FijiConditionCodeVS](ValueSet-fiji-condition-code-vs.md), [FijiDiagnosticObservation](StructureDefinition-fiji-diagnostic-observation.md), [FijiEncounter](StructureDefinition-fiji-encounter.md), [FijiEncounterReasonVS](ValueSet-fiji-encounter-reason-vs.md), [FijiEvidenceVS](ValueSet-fiji-evidence-vs.md), [FijiFacility](StructureDefinition-fiji-facility.md), [FijiHeight](StructureDefinition-fiji-vital-height.md), [FijiImagingDiagnosticReport](StructureDefinition-fiji-imaging-diagnostic-report.md), [FijiImmunization](StructureDefinition-fiji-immunization.md), [FijiMedVS](ValueSet-fiji-med-vs.md), [FijiMedicationDispense](StructureDefinition-fiji-medication-dispense.md), [FijiMedicationRequest](StructureDefinition-fiji-medication-request.md), [FijiMedicationRequestReasonVS](ValueSet-fiji-medication-request-reason-vs.md), [FijiMedicationRouteVS](ValueSet-fiji-medication-route-vs.md), [FijiOrganizationRoleVS](ValueSet-fiji-organization-role-vs.md), [FijiOxygenSaturation](StructureDefinition-fiji-vital-oxygen-saturation.md), [FijiProcedure](StructureDefinition-fiji-procedure.md), [FijiRadiologyFindingsVS](ValueSet-fiji-radiology-findings-vs.md), [FijiRespiratoryRate](StructureDefinition-fiji-vital-respiratory-rate.md), [FijiServiceTypeVS](ValueSet-fiji-service-type-vs.md), [FijiVitalBloodPressure](StructureDefinition-fiji-vital-blood-pressure.md), [FijiVitalBodyTemperature](StructureDefinition-fiji-vital-body-temperature.md), [FijiVitalHeartRate](StructureDefinition-fiji-vital-heart-rate.md), [FijiVitalMethodVS](ValueSet-fiji-vital-method-vs.md), [Immunization/FijiImmunizationReactionExample](Immunization-FijiImmunizationReactionExample.md), [Immunization/FijiTdapImmunizationExample](Immunization-FijiTdapImmunizationExample.md), [MedicationDispense/FijiMedicationDispenseExample](MedicationDispense-FijiMedicationDispenseExample.md), [MedicationRequest/FijiMedicationRequestExample](MedicationRequest-FijiMedicationRequestExample.md), [Namosi District Hospital](Organization-FijiHospitalExample.md), [Navua Community Clinic](Organization-FijiClinicExample.md), [Observation/ExampleBloodPressure](Observation-ExampleBloodPressure.md), [Observation/FijiBodyTemperatureExample](Observation-FijiBodyTemperatureExample.md), [Observation/FijiDiagnosticObservationChestXrayReport](Observation-FijiDiagnosticObservationChestXrayReport.md), [Observation/FijiDiagnosticObservationPleuralEffusion](Observation-FijiDiagnosticObservationPleuralEffusion.md), [Observation/FijiDiagnosticObservationPulmonaryConsolidation](Observation-FijiDiagnosticObservationPulmonaryConsolidation.md), [Observation/FijiTdapReactionObservation](Observation-FijiTdapReactionObservation.md), [Observation/HeartRateExample](Observation-HeartRateExample.md), [Observation/RespiratoryRateExample](Observation-RespiratoryRateExample.md), [Procedure/AppendectomyProcedureExample](Procedure-AppendectomyProcedureExample.md), [ServiceRequest/sr-ct-head-001](ServiceRequest-sr-ct-head-001.md) and [Specimen/ExampleLipidSpecimen](Specimen-ExampleLipidSpecimen.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.5.0/CodeSystem-allergyintolerance-clinical.html): [AllergyIntolerance/FijiAllergyIntoleranceExample](AllergyIntolerance-FijiAllergyIntoleranceExample.md)
* [AllergyIntolerance Verification Status](http://terminology.hl7.org/7.5.0/CodeSystem-allergyintolerance-verification.html): [AllergyIntolerance/FijiAllergyIntoleranceExample](AllergyIntolerance-FijiAllergyIntoleranceExample.md)
* [Condition Category Codes](http://terminology.hl7.org/7.5.0/CodeSystem-condition-category.html): [Condition/condition-example-diabetes2](Condition-condition-example-diabetes2.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.5.0/CodeSystem-condition-clinical.html): [Condition/condition-example-diabetes2](Condition-condition-example-diabetes2.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/7.5.0/CodeSystem-condition-ver-status.html): [Condition/condition-example-diabetes2](Condition-condition-example-diabetes2.md)
* [DataAbsentReason](http://terminology.hl7.org/7.5.0/CodeSystem-data-absent-reason.html): [FijiDiagnosticObservation](StructureDefinition-fiji-diagnostic-observation.md) and [FijiPathologyObservation](StructureDefinition-fiji-pathology-observation.md)
* [Observation Category Codes](http://terminology.hl7.org/7.5.0/CodeSystem-observation-category.html): [FijiPathologyObservation](StructureDefinition-fiji-pathology-observation.md), [Observation/Example-BMI](Observation-Example-BMI.md)... Show 14 more, [Observation/Example-BodyHeight](Observation-Example-BodyHeight.md), [Observation/Example-BodyWeight](Observation-Example-BodyWeight.md), [Observation/ExampleArterialPO2](Observation-ExampleArterialPO2.md), [Observation/ExampleBloodPressure](Observation-ExampleBloodPressure.md), [Observation/ExampleHDLCholesterol](Observation-ExampleHDLCholesterol.md), [Observation/ExampleLDLCholesterol](Observation-ExampleLDLCholesterol.md), [Observation/ExampleLipidPanel](Observation-ExampleLipidPanel.md), [Observation/ExampleTotalCholesterol](Observation-ExampleTotalCholesterol.md), [Observation/ExampleTriglycerides](Observation-ExampleTriglycerides.md), [Observation/FijiBodyTemperatureExample](Observation-FijiBodyTemperatureExample.md), [Observation/FijiHeadCircumferenceExample](Observation-FijiHeadCircumferenceExample.md), [Observation/HeartRateExample](Observation-HeartRateExample.md), [Observation/OxygenSaturationExample](Observation-OxygenSaturationExample.md) and [Observation/RespiratoryRateExample](Observation-RespiratoryRateExample.md)
* [Participant type](http://terminology.hl7.org/7.5.0/CodeSystem-participant-type.html): [FijiEncounter](StructureDefinition-fiji-encounter.md)
* [diagnosticServiceSectionId](http://terminology.hl7.org/7.5.0/CodeSystem-v2-0074.html): [DiagnosticReport/ExampleLipidPanelReport](DiagnosticReport-ExampleLipidPanelReport.md), [DiagnosticReport/dr-ct-head-001](DiagnosticReport-dr-ct-head-001.md)... Show 6 more, [FijiDiagnosticObservation](StructureDefinition-fiji-diagnostic-observation.md), [FijiImagingDiagnosticReport](StructureDefinition-fiji-imaging-diagnostic-report.md), [FijiLaboratoryDiagnosticReport](StructureDefinition-fiji-laboratory-diagnostic-report.md), [Observation/FijiDiagnosticObservationChestXrayReport](Observation-FijiDiagnosticObservationChestXrayReport.md), [Observation/FijiDiagnosticObservationPleuralEffusion](Observation-FijiDiagnosticObservationPleuralEffusion.md) and [Observation/FijiDiagnosticObservationPulmonaryConsolidation](Observation-FijiDiagnosticObservationPulmonaryConsolidation.md)
* [specimenType](http://terminology.hl7.org/7.5.0/CodeSystem-v2-0487.html): [Specimen/FijiSpecimenExample](Specimen-FijiSpecimenExample.md)
* [ActCode](http://terminology.hl7.org/7.5.0/CodeSystem-v3-ActCode.html): [Encounter/FijiEncounterExample](Encounter-FijiEncounterExample.md) and [FijiEncounter](StructureDefinition-fiji-encounter.md)
* [ObservationInterpretation](http://terminology.hl7.org/7.5.0/CodeSystem-v3-ObservationInterpretation.html): [FijiBMI](StructureDefinition-fiji-vital-bmi.md), [FijiHeadCircumference](StructureDefinition-fiji-vital-head-circumference.md)... Show 13 more, [FijiHeight](StructureDefinition-fiji-vital-height.md), [FijiObsInterpretationVS](ValueSet-fiji-obs-interpretation-vs.md), [FijiOxygenSaturation](StructureDefinition-fiji-vital-oxygen-saturation.md), [FijiPathologyObservation](StructureDefinition-fiji-pathology-observation.md), [FijiRespiratoryRate](StructureDefinition-fiji-vital-respiratory-rate.md), [FijiVitalBloodPressure](StructureDefinition-fiji-vital-blood-pressure.md), [FijiVitalBodyTemperature](StructureDefinition-fiji-vital-body-temperature.md), [FijiVitalHeartRate](StructureDefinition-fiji-vital-heart-rate.md), [FijiWeight](StructureDefinition-fiji-vital-weight.md), [Observation/Example-BMI](Observation-Example-BMI.md), [Observation/ExampleBloodPressure](Observation-ExampleBloodPressure.md), [Observation/FijiBodyTemperatureExample](Observation-FijiBodyTemperatureExample.md) and [Observation/OxygenSaturationExample](Observation-OxygenSaturationExample.md)
* [ParticipationType](http://terminology.hl7.org/7.5.0/CodeSystem-v3-ParticipationType.html): [Encounter/FijiEncounterExample](Encounter-FijiEncounterExample.md) and [FijiEncounter](StructureDefinition-fiji-encounter.md)


