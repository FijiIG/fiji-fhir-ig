# Fiji Diagnostic Observation - Pulmonary Consolidation - Draft Fiji Core Implementation Guide v0.2.2

## Example Observation: Fiji Diagnostic Observation - Pulmonary Consolidation

Profile: [Fiji Diagnostic Observation](StructureDefinition-fiji-diagnostic-observation.md)

**status**: Final

**category**: Radiology

**code**: Pulmonary consolidation

**subject**: [Jone Nabou Male, DoB: 1992-04-17 ( http://fhir.health.gov.fj/identifier/national-health-number#FijiPatientIdentifier#FJ-NHI-982345671)](Patient-FijiPatientExample.md)

**effective**: 2026-09-28 09:30:00+1200

**performer**: [Practitioner/FijiRadiologistExample](Practitioner/FijiRadiologistExample)

**bodySite**: Lung structure



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "FijiDiagnosticObservationPulmonaryConsolidation",
  "meta" : {
    "profile" : ["https://core.fhir.health.gov.fj/StructureDefinition/fiji-diagnostic-observation"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
      "code" : "RAD",
      "display" : "Radiology"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "95436008",
      "display" : "Pulmonary consolidation"
    }]
  },
  "subject" : {
    "reference" : "Patient/FijiPatientExample"
  },
  "effectiveDateTime" : "2026-09-28T09:30:00+12:00",
  "performer" : [{
    "reference" : "Practitioner/FijiRadiologistExample"
  }],
  "bodySite" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "39607008",
      "display" : "Lung structure"
    }]
  }
}

```
