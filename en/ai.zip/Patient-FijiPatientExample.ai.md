# Fiji Patient - iTaukei - Draft Fiji Core Implementation Guide v0.9.0

## Example Patient: Fiji Patient - iTaukei

Profile: [Fiji Patient](StructureDefinition-fiji-patient.md)

Jone Nabou Male, DoB: 1992-04-17 ( http://fhir.health.gov.fj/identifier/national-health-number#FijiPatientIdentifier#FJ-NHI-982345671)

-------

| | |
| :--- | :--- |
| Alt. Name: | Jone Nabou(Official) |
| Contact Detail | Nadi Village, Ba Province |
| Fiji iTaukei Affiliation: | * yasana: Bua
* tikina: Dama Tikina
* korodina: NagaDoa
* yavusa: Kai Narocake
* mataqali: Tova Natokalau
* tokatoka: Tk Bureta
 |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "FijiPatientExample",
  "meta" : {
    "profile" : ["https://core.fhir.health.gov.fj/StructureDefinition/fiji-patient"]
  },
  "extension" : [{
    "extension" : [{
      "url" : "yasana",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://core.fhir.health.gov.fj/CodeSystem/fiji-yasana",
          "code" : "bua",
          "display" : "Bua"
        }]
      }
    },
    {
      "url" : "tikina",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://core.fhir.health.gov.fj/CodeSystem/fiji-tikina",
          "code" : "dama",
          "display" : "Dama Tikina"
        }]
      }
    },
    {
      "url" : "korodina",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://core.fhir.health.gov.fj/CodeSystem/fiji-korodina",
          "code" : "nagadoa",
          "display" : "NagaDoa"
        }]
      }
    },
    {
      "url" : "yavusa",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://core.fhir.health.gov.fj/CodeSystem/fiji-yavusa",
          "code" : "kai-narocake",
          "display" : "Kai Narocake"
        }]
      }
    },
    {
      "url" : "mataqali",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://core.fhir.health.gov.fj/CodeSystem/fiji-mataqali",
          "code" : "tova-natokalau",
          "display" : "Tova Natokalau"
        }]
      }
    },
    {
      "url" : "tokatoka",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "https://core.fhir.health.gov.fj/CodeSystem/fiji-tokatoka",
          "code" : "tk-bureta",
          "display" : "Tk Bureta"
        }]
      }
    }],
    "url" : "https://core.fhir.health.gov.fj/StructureDefinition/fiji-iTaukei-affiliation"
  }],
  "identifier" : [{
    "system" : "http://fhir.health.gov.fj/identifier/national-health-number",
    "value" : "FJ-NHI-982345671"
  }],
  "name" : [{
    "use" : "official",
    "text" : "Jone Nabou",
    "family" : "Nabou",
    "given" : ["Jone"]
  },
  {
    "use" : "usual",
    "text" : "Jone Nabou",
    "given" : ["Jone"]
  }],
  "gender" : "male",
  "birthDate" : "1992-04-17",
  "address" : [{
    "text" : "Nadi Village, Ba Province",
    "country" : "FJ"
  }]
}

```
