# Fiji Address - Draft Fiji Core Implementation Guide v0.9.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Fiji Address**

## Data Type Profile: Fiji Address 

| | |
| :--- | :--- |
| *Official URL*:https://core.fhir.health.gov.fj/StructureDefinition/fiji-address | *Version*:0.9.1 |
| Active as of 2026-11-27 | *Computable Name*:FijiAddress |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.40.1005.42.2 | |
| **Copyright/Legal**: Distributed under the Creative Commons CC0-1.0 License (https://creativecommons.org/publicdomain/zero/1.0/) | |

 
Address profile designed for Fiji addresses which may include descriptive and village-based rather than street-based locations. 
 This profile supports a range of address formats and general usage guidance. In all cases: 
* text is a mandatory field and should be considered the primary representation of the fully address.
* line is used for free text address lines and may relate to a landmark, school, church etc. in some cases combined with a village or settlement name - rather than a street address.
* Country supports international interoperability
* geolocation is added as an optional extension to support use case where GPS coordinates are available. It is expected that this will become more common.
 
This is used by FijiPatient, FijiPractitioner, FijiLocation and FijiOrganization. 
Recommended mapping of address fields are below but should be validated and used with Fiji specific examples. 

| | | |
| :--- | :--- | :--- |
| `text` | Full narrative address | (required) Often the primary address form |
| `line` | May include Landmark, compound or street | Free-text |
| `city` | Town | May be used for urban areas but also smaller centres |
| `district` | District | District, ward, or sub-provincial administrative area |
| `state` | Division | Province, division, or first-level administrative region |
| `extension:geolocation` | Geolocation coordinates | Lat/Long coordinates |

 

**Usages:**

* Use this DataType Profile: [Fiji Healthcare Administrative Zone](StructureDefinition-fiji-administrative-zone.md), [Fiji Healthcare Facility or Organization](StructureDefinition-fiji-facility.md), [Fiji Healthcare Location](StructureDefinition-fiji-location.md), [Fiji Patient](StructureDefinition-fiji-patient.md) and [Fiji Practitioner](StructureDefinition-fiji-practitioner.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/fj.gov.health.fhir.core|current/StructureDefinition/StructureDefinition-fiji-address.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-fiji-address.csv), [Excel](StructureDefinition-fiji-address.xlsx), [Schematron](StructureDefinition-fiji-address.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fiji-address",
  "url" : "https://core.fhir.health.gov.fj/StructureDefinition/fiji-address",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.4.642.40.1005.42.2"
  }],
  "version" : "0.9.1",
  "name" : "FijiAddress",
  "title" : "Fiji Address",
  "status" : "active",
  "date" : "2026-11-27T08:01:49+00:00",
  "publisher" : "MHMS Fiji",
  "contact" : [{
    "name" : "MHMS Fiji",
    "telecom" : [{
      "system" : "url",
      "value" : "https://fhir.health.gov.fj"
    }]
  },
  {
    "name" : "Support",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.fhir.health.gov.fj"
    }]
  }],
  "description" : "Address profile designed for Fiji addresses which may include descriptive and village-based rather than \nstreet-based locations.   \nThis profile supports a range of address formats and general usage guidance.\nIn all cases:\n- text is a mandatory field and should be considered the primary representation of the fully address.\n- line is used for free text address lines and may relate to a landmark, school, church etc. in some cases combined with a village or settlement name - rather than a street address.\n- Country supports international interoperability\n- geolocation is added as an optional extension to support use case where GPS coordinates are available. It is expected that this will become more common.\n\nThis is used by FijiPatient, FijiPractitioner, FijiLocation and FijiOrganization.\n\nRecommended mapping of address fields are below but should be validated and used with Fiji specific examples.\n\n| FHIR Element        | Typical Use            | Notes                          |\n| ------------------- | ------------------------------ | ------------------------------ |\n| `text`              | Full narrative address         | (required) Often the primary address form |\n| `line`              | May include Landmark, compound or street     | Free-text                      |\n| `city`              | Town                          | May be used for urban areas but also smaller centres            |\n| `district`          | District              | District, ward, or sub-provincial administrative area              |\n| `state`             | Division              | Province, division, or first-level administrative region              |\n| `extension:geolocation` | Geolocation coordinates    | Lat/Long coordinates        |",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FJ",
      "display" : "Fiji"
    }]
  }],
  "copyright" : "Distributed under the Creative Commons CC0-1.0 License (https://creativecommons.org/publicdomain/zero/1.0/)",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  },
  {
    "identity" : "vcard",
    "uri" : "http://w3.org/vcard",
    "name" : "vCard Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "type" : "Address",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Address",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Address",
      "path" : "Address"
    },
    {
      "id" : "Address.extension:geolocation",
      "path" : "Address.extension",
      "sliceName" : "geolocation",
      "short" : "Geographic coordinates of the address.",
      "definition" : "Latitude and longitude coordinates representing the geographic location of the address. May represent household, facility, or village centroid.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/geolocation|4.0.1"]
      }]
    },
    {
      "id" : "Address.text",
      "path" : "Address.text",
      "short" : "Full descriptive address, should be considered the primary representation of the address",
      "definition" : "The complete address as written or spoken locally. This is the primary form of the address and may include village, island, landmarks, or other narrative description.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Address.line",
      "path" : "Address.line",
      "short" : "Free text address lines may refer to proximity to landmarks (e.g.school, church etc.)",
      "definition" : "Address line components used for landmarks, household names, compound identifiers, street names, or other free-text address components.",
      "mustSupport" : true
    },
    {
      "id" : "Address.city",
      "path" : "Address.city",
      "short" : "Town or urban locality.",
      "definition" : "The city or town for the address. In rural areas this element may be absent.",
      "mustSupport" : true
    },
    {
      "id" : "Address.district",
      "path" : "Address.district",
      "short" : "District, ward, or sub-provincial administrative area.",
      "definition" : "Administrative subdivision below the province or state level. May represent district, ward, or similar administrative unit depending on national administrative structures.",
      "mustSupport" : true
    },
    {
      "id" : "Address.state",
      "path" : "Address.state",
      "short" : "Province, division, or first-level administrative region.",
      "definition" : "First-level administrative region such as province, division, or region depending on national geography.",
      "mustSupport" : true
    },
    {
      "id" : "Address.postalCode",
      "path" : "Address.postalCode",
      "short" : "Postal code is currently optional"
    },
    {
      "id" : "Address.country",
      "path" : "Address.country",
      "short" : "Country is required for international interoperability. Use ISO 3166 two-letter country codes.",
      "definition" : "Country expressed using ISO 3166 two-letter country codes.",
      "min" : 1,
      "mustSupport" : true
    }]
  }
}

```
